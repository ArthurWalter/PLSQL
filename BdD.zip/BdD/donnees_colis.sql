INSERT INTO `client` VALUES('CL1', 'Bernard H.', 'Metz');
INSERT INTO `client` VALUES('CL2', 'Anne S.', 'Strasbourg');
INSERT INTO `client` VALUES('CL3', 'Zsuzsanna R.', 'Metz');

INSERT INTO `produit` VALUES('P1', 'crayon', 1.20, 4);
INSERT INTO `produit` VALUES('P2', 'cahier', 2.30, 10);
INSERT INTO `produit` VALUES('P3', 'gomme', 0.70, 150);
INSERT INTO `produit` VALUES('P4', 'agrafeuse', 17.90, 6);

INSERT INTO `commande` VALUES('C1', '2016-09-01', 'CL1');
INSERT INTO `commande` VALUES('C2', '2016-09-23', 'CL1');
INSERT INTO `commande` VALUES('C3', '2016-09-23', 'CL2');
INSERT INTO `commande` VALUES('C4', '2016-09-25', 'CL3');

INSERT INTO `ligne_com` VALUES('C1', 'P1', 5);
INSERT INTO `ligne_com` VALUES('C1', 'P2', 2);
INSERT INTO `ligne_com` VALUES('C2', 'P2', 1);
INSERT INTO `ligne_com` VALUES('C3', 'P1', 10);
INSERT INTO `ligne_com` VALUES('C3', 'P2', 3);
INSERT INTO `ligne_com` VALUES('C3', 'P3', 1);
INSERT INTO `ligne_com` VALUES('C3', 'P4', 1);
INSERT INTO `ligne_com` VALUES('C4', 'P4', 1);

INSERT INTO `colis` VALUES('Co1', 'C1', '2016-09-03');
INSERT INTO `colis` VALUES('Co2', 'C1', '2016-09-11');
INSERT INTO `colis` VALUES('Co3', 'C2', '2016-09-30');

INSERT INTO `livre` VALUES('Co1', 'P1', 2);
INSERT INTO `livre` VALUES('Co1', 'P2', 2);
INSERT INTO `livre` VALUES('Co2', 'P1', 3);
INSERT INTO `livre` VALUES('Co2', 'P2', 1);


