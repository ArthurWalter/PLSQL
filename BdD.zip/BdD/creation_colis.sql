CREATE TABLE client(
        mat_cl 		VARCHAR (10) NOT NULL ,
        nom_cl 	VARCHAR (20) NOT NULL ,
        ad_cli 		VARCHAR (40) NOT NULL ,
        PRIMARY KEY (mat_cl)
)ENGINE=InnoDB;

CREATE TABLE commande(
        no_com   	VARCHAR (10) NOT NULL ,
        date_com 	DATE NOT NULL ,
        mat_cl   	VARCHAR (10) NOT NULL ,
        PRIMARY KEY (no_com ) ,
		FOREIGN KEY (mat_cl) REFERENCES client(mat_cl)
)ENGINE=InnoDB;

CREATE TABLE produit(
        code_prod 	VARCHAR (10) NOT NULL ,
        nom_prod  	VARCHAR (40) NOT NULL ,
        prix_unit 	DECIMAL (6,2) NOT NULL ,
        qte_stock 	INT NOT NULL ,
        PRIMARY KEY (code_prod)
)ENGINE=InnoDB;

CREATE TABLE colis(
        no_colis   	VARCHAR (10) NOT NULL ,
		no_com   	VARCHAR (10) NOT NULL ,
        date_colis 	DATE NOT NULL ,
        PRIMARY KEY (no_colis) ,
		FOREIGN KEY (no_com) REFERENCES commande(no_com)
)ENGINE=InnoDB;

CREATE TABLE ligne_com(    
        no_com    	VARCHAR (10) NOT NULL ,
        code_prod 	VARCHAR (10) NOT NULL ,
 		qte_cdee  	INT NOT NULL ,
        PRIMARY KEY (no_com ,code_prod ) ,
		FOREIGN KEY (no_com) REFERENCES commande(no_com) ,
		FOREIGN KEY (code_prod) REFERENCES produit(code_prod)
)ENGINE=InnoDB;

CREATE TABLE livre(     
        no_colis  	VARCHAR (10) NOT NULL ,
        code_prod 	VARCHAR (10) NOT NULL ,
		qte_liv   	INT ,      
        PRIMARY KEY (no_colis ,code_prod) ,
		FOREIGN KEY (no_colis) REFERENCES colis(no_colis) ,
		FOREIGN KEY (code_prod) REFERENCES produit(code_prod)
)ENGINE=InnoDB;
