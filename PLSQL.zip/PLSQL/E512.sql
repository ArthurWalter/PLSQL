E512	CREATE PROCEDURE sp_palindrome (IN phrase VARCHAR(200), OUT resultat BOOLEAN)
BEGIN
	DECLARE v_latin varchar(200) DEFAULT LOWER(TRIM(phrase));
	SET v_latin := REPLACE(v_latin,"'","");
	SET v_latin := REPLACE(v_latin,"é","e");
	SET v_latin := REPLACE(v_latin,"è","e");
	SET v_latin := REPLACE(v_latin,"ê","e");
	SET v_latin := REPLACE(v_latin,"ë","e");
	SET v_latin := REPLACE(v_latin,"à","a");
	SET v_latin := REPLACE(v_latin,"â","a");
	SET v_latin := REPLACE(v_latin,"ä","a");
	SET v_latin := REPLACE(v_latin,"ï","i");
	SET v_latin := REPLACE(v_latin,"î","i");
	SET v_latin := REPLACE(v_latin,"ô","o");
	SET v_latin := REPLACE(v_latin,"ö","o");
	SET v_latin := REPLACE(v_latin,"ù","u");
	SET v_latin := REPLACE(v_latin,"û","u");
	SET v_latin := REPLACE(v_latin,"ü","u");
	SET v_latin := REPLACE(v_latin,"ç","c");
	SET v_latin := REPLACE(v_latin,",","");	
	SET v_latin := REPLACE(v_latin," ","");
	SET v_latin := REPLACE(v_latin,"!","");
	SET v_latin := REPLACE(v_latin,".","");
	SET resultat := v_latin = REVERSE(v_latin);
END;

