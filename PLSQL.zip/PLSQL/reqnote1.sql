-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: comments before and after the routine body will not be stored by the server
-- --------------------------------------------------------------------------------
DELIMITER $$

CREATE DEFINER=`walter59u_appli`@`%` PROCEDURE `sp_moymod_etud`(IN idetud INT, IN idmod INT, OUT moy DECIMAL(4,2))
BEGIN
DECLARE v_moy, i int;
DECLARE v_note INT;
DECLARE	fincurs1 BOOLEAN DEFAULT 0;
	DECLARE curs1 CURSOR FOR
 			SELECT N.note
			FROM MODULE M, ETUDIANT E, CONTROLE C, NOTER N
			WHERE M.mod_id = C.mod_id
			AND C.ctrl_id = N.ctrl_id
			AND N.etud_id = E.etud_id
			AND idetud = E.etud_id
			AND idmod = M.mod_id
			group by ctrl_id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;
	
SET i := 0;
OPEN curs1;
FETCH curs1 INTO v_note;

		WHILE NOT fincurs1 
		DO
			set v_moy = v_moy + note;
			set i := i+1;
		end while;
close curs1;
set  moy := v_moy / i;
END