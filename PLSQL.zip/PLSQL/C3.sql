CREATE PROCEDURE  sp_recette_jour_niveau 
			 (IN nojour INT, IN nivid INT,  OUT recette DECIMAL(7,2))
BEGIN
	DECLARE v_entid INT;
	DECLARE v_recette DECIMAL(7,2) DEFAULT 0;	-- ATTENTION : 5 chiffres avant la décimale
	DECLARE v_prix DECIMAL(4,2);

	DECLARE	fincurs1 BOOLEAN DEFAULT 0;
	
	DECLARE curs1 CURSOR FOR
		SELECT	ent_id
		FROM	ENTRÉE
		WHERE	jour_in=nojour
		AND		niv_id=nivid;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;

	OPEN curs1;
	FETCH curs1 INTO v_entid;
	WHILE NOT fincurs1 DO
		CALL  sp_calcul_entree (v_entid, v_prix);
		IF v_prix IS NOT NULL
		THEN
			SET v_recette := v_recette +v_prix;
		END IF ;
		FETCH curs1 INTO v_entid;
	END WHILE;
	CLOSE curs1;
	SET recette := v_recette;
END

