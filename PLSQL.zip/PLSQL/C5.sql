CREATE PROCEDURE  sp_prix_moyen_jour 
			 (IN nojour INT,  OUT prixmoyen DECIMAL(7,2))
BEGIN
	DECLARE v_nb INT;
	DECLARE v_recette DECIMAL(7,2);
	DECLARE v_moyen DECIMAL(4,2);
	CALL  sp_recette_jour (nojour, v_recette);
	SELECT COUNT(*) INTO v_nb FROM ENTREE WHERE jour_in=nojour ;
	SET v_moyen := v_recette / v_nb ;
	SET prixmoyen := v_moyen;
END
