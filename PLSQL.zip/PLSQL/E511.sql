CREATE PROCEDURE  sp_caisse_market  (IN achat INT, IN reglement INT)
BEGIN
	DECLARE	v_monnaie, v_b10, v_b5, v_pc2, v_pc1 INT DEFAULT 0;
	DECLARE v_rendu VARCHAR(80) DEFAULT '';
	IF reglement = achat
	THEN
		SET v_rendu:='Le compte est bon.';
	ELSEIF reglement < achat
	THEN 
-- deux possibilités pour insérer l'apostrophe dans une chaîne : '' ou \'
		SET v_rendu:='vous n''avez pas assez d\'argent, vous déposez vos achats et vous partez !';
		SET v_b10:=null	SET v_b5:=null;
		SET v_pc2:=null;	SET v_pc1:=null;
	ELSE
		SET v_monnaie:=reglement - achat; 
		SET v_b10:=v_monnaie DIV 10;
		IF v_b10>0
		THEN
			SET v_rendu:=CONCAT(v_rendu,v_b10,' billet');
			IF v_b10>1
			THEN
				SET v_rendu:=CONCAT(v_rendu,'s ');
			END IF;
			SET v_rendu:=CONCAT(v_rendu,' de 10€, '); 
		END IF;
		
		SET v_monnaie:=v_monnaie -v_b10*10; 
		SET v_b5:=v_monnaie DIV 5;
		IF v_b5>0
		THEN
			SET v_rendu:=CONCAT(v_rendu,v_b5,' billet');
			IF v_b5>1
			THEN
				SET v_rendu:=CONCAT(v_rendu,'s ');
			END IF;
			SET v_rendu:=CONCAT(v_rendu,' de 5€, '); 
		END IF;

		SET v_monnaie:=v_monnaie -v_b5*5; 
		SET v_pc2:=v_monnaie DIV 2;
		IF v_pc2>0
		THEN
			SET v_rendu:=CONCAT(v_rendu,v_pc2,' pièce');
			IF v_pc2>1
			THEN
				SET v_rendu:=CONCAT(v_rendu,'s ');
			END IF;
			SET v_rendu:=CONCAT(v_rendu,' de 2€, '); 
		END IF;
		
		SET v_pc1:=v_monnaie -v_pc2*2;
		IF v_pc1>0
		THEN
			SET v_rendu:=CONCAT(v_rendu,v_pc1,' pièce de 1€,');
		END IF;
		SET v_rendu:=LEFT(v_rendu,LENGTH(v_rendu) -1);
	END IF;
	SELECT v_b10 AS 'billet de 10', v_b5 AS 'billet de 5'
			,v_pc2 AS 'pièce de 2', v_pc1 AS 'pièce de 1'
			,v_rendu AS résultat;
END;
