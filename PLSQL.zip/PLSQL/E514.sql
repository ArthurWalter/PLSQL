CREATE PROCEDURE  sp_fibonacci  (IN nombre INT)
BEGIN
	DECLARE v_n2 INT DEFAULT 0;
	DECLARE v_n1 INT DEFAULT 1;
	DECLARE v_n  INT DEFAULT 1;
	DECLARE i INT DEFAULT 0;
 
	DECLARE erreur BOOLEAN DEFAULT false;
	BEGIN 
		DECLARE EXIT HANDLER FOR 1051

		SET erreur := true;  

		DROP TABLE TMP_FIBO;

	END;

	CREATE TEMPORARY TABLE TMP_FIBO (indice INT, valeur INT);
	INSERT INTO TMP_FIBO VALUES (i, 1);
	WHILE i<nombre DO
		SET i:=i+1; 
		SET v_n:=v_n1 + v_n2;
		INSERT INTO TMP_FIBO VALUES (i, v_n);
		SET v_n2 := v_n1;
		SET v_n1 := v_n;
	END WHILE;
	SELECT 'Fin de la création' AS 'résultat';
END

