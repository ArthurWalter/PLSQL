

prendre la moyenne d'un module et l'ajouter à v_moyue (+ prendre en compte le coef du module)
 puis diviser par le nb de module;

-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: comments before and after the routine body will not be stored by the server
-- --------------------------------------------------------------------------------
DELIMITER $$

CREATE PROCEDURE `so_moyue_etud` (IN idetud INT, IN idue INT, OUT moy DECIMAL(4,2))
BEGIN

DECLARE  i,v_moy,v_mod , v_note,v_note2 ,v_modcoef INT;
DECLARE	fincurs1 BOOLEAN DEFAULT 0;
DECLARE curs1 CURSOR FOR 
	SELECT mod_id, mod_coef
	FROM MODULE M, ETUDIANT E, NOTER N, CONTROLE C
	WHERE M.ue_id = idue
	AND N.etud_id = idetud
	AND M.mod_id = C.mod_id
	AND C.ctrl_id = N.ctrl_id;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;

OPEN curs1;
FETCH curs1 INTO v_mod, v_modcoef;
WHILE NOT fincurs1
DO
	
	CALL sp_moymod_etud(idetud, v_mod, v_note)
	SET v_note INTO v_note2
	SET v_moy := v_moy + (v_note2 * v_mod coef)
	SET i := i+1
	FETCH curs1 INTO v_mod, v_modcoef;

end while;
SET moy := v_moy / i;

END



BEGIN
DECLARE v_msg VARCHAR(50);
DECLARE curs1 CURSOR FOR
	CALL sp_moyue_etud(nom, idue, moy);
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;
IF moy IS NOT NULL
then 
SET titre_msg := CONCAT( 'Moyenne UE ', idue,' de ', nom,' au ',DATE(NOW())) -- à renvoyer en sortie si marche
 ELSE IF 

END