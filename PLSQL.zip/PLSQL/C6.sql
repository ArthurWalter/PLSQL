CREATE PROCEDURE  sp_duree_moyenne_jour  (IN nojour INT,  OUT duree TIME)
BEGIN
	DECLARE v_moyen INT;
	SELECT AVG(jour_out*1440 +heure_out -(jour_in*1440 +heure_in)) INTO v_moyen
	FROM ENTREE WHERE jour_in=nojour ;
	SET duree := SEC_TO_TIME(v_moyen*60);
END