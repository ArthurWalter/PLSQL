CREATE  PROCEDURE  sp_niveau_maxaffluence  ( )
BEGIN
	DECLARE v_nivid, v_pos INT;
	DECLARE v_nivlib VARCHAR(20);
	DECLARE v_res VARCHAR(20);
	DECLARE v_affluence INT;

	DECLARE flagNotFound BOOLEAN DEFAULT false;
	DECLARE	fincurs1 BOOLEAN DEFAULT 0;

	DECLARE curs1 CURSOR FOR
			SELECT	DISTINCT niv_id, niv_lib
			FROM	NIVEAU;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;

	BEGIN 
		DECLARE EXIT HANDLER FOR 1051 SET flagNotFound := true;  
		DROP TABLE TMP_AFFLU_NIVEAU;
	END;
	CREATE TEMPORARY TABLE TMP_AFFLU_NIVEAU (numéro INT, libellé VARCHAR(20), 
			affluence INT, jour INT, mois INT );

	OPEN curs1;
	FETCH curs1 INTO v_nivid, v_nivlib;
	WHILE NOT fincurs1 DO
		CALL sp_maxaffluence(v_nivid,v_res);
		IF v_res IS NOT NULL	
		THEN
			SET v_pos := LOCATE(';',v_res);
			SET v_affluence := SUBSTR(v_res,v_pos+1);
			SET v_res := SUBSTR(v_res,1,v_pos-1);
			INSERT INTO TMP_AFFLU_NIVEAU 
			VALUES (v_nivid, v_nivlib, v_affluence, LEFT(v_res,2), RIGHT(v_res,2));
		END IF;
		FETCH curs1 INTO v_nivid, v_nivlib;
	END WHILE;
	CLOSE curs1;
END
