

	BEGIN
	declare v_etud_id int default 0;
	declare v_msg varchar(50);
	declare v_moy decimal(4,2) default 0;
	DECLARE NomNotFound BOOLEAN DEFAULT false;
	DECLARE MoyNotFound BOOLEAN DEFAULT false;

	select E.etud_id into v_etud_id
	from ETUDIANT E
	where E.etud_nom=nom;

	call sp_moyue_etud(v_etud_id,idue,v_moy);

	IF  v_moy IS NULL
		THEN 
			SET MoyNotFound := true;
		END IF;
	
	IF v_moy IS NOT NULL then 
		SET v_msg := CONCAT( 'Moyenne UE ', idue,' de ', nom,' au ',DATE(NOW())); 
	END IF;
	
	IF (v_moy IS NULL) AND (v_etud_id IS NULL) THEN 
		SET  v_msg := CONCAT( 'L"étudiant', nom, 'n"est pas inscrit !');
	END IF;
	
	IF v_moy is NULL then
		SET v_msg := CONCAT( ' L"étudiant', nom, ' n"a aucune note au', DATE(NOW()));
	end if;



	set moy:=v_moy;
	set titre_msg:=v_msg;

	END

