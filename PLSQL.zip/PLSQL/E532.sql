CREATE  PROCEDURE sp_liste_abonne_annuel ( )
BEGIN
	DECLARE v_aboid INT;
	DECLARE v_annuel BOOLEAN;
	DECLARE v_ident varchar(40);

	DECLARE flagNotFound BOOLEAN DEFAULT false;
	DECLARE	fincurs1 BOOLEAN DEFAULT 0;

	DECLARE curs1 CURSOR FOR
 			SELECT	DISTINCT abo_id, CONCAT(abo_nom,' ',abo_prn)
			FROM	ABONNE;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;

	BEGIN 
		DECLARE EXIT HANDLER FOR 1051 SET flagNotFound := true;  
		DROP TABLE TMP_ABOAN;
	END;
	CREATE TEMPORARY TABLE TMP_ABOAN (numéro INT, identité VARCHAR(40));

	OPEN curs1;
	FETCH curs1 INTO v_aboid, v_ident;
	WHILE NOT fincurs1 DO
		CALL   sp_abonne_annuel(v_aboid,v_annuel);
		IF v_annuel
		THEN
			 INSERT INTO TMP_ABOAN VALUES (v_aboid, v_ident);
		END IF;
		FETCH curs1 INTO v_aboid, v_ident;
	END WHILE;
	CLOSE curs1;
END
