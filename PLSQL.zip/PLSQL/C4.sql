CREATE PROCEDURE  sp_recette_jour 
			 (IN nojour INT,  OUT recette DECIMAL(7,2))
BEGIN
	DECLARE v_nivid INT;
	DECLARE v_recette DECIMAL(7,2) DEFAULT 0;
	DECLARE v_prix DECIMAL(7,2);	-- !! : 5 chiffres avant la décimale

	DECLARE	fincurs1 BOOLEAN DEFAULT 0;
	
	DECLARE curs1 CURSOR FOR
		SELECT	DISTINCT niv_id
		FROM	NIVEAU;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET fincurs1:=1;

	OPEN curs1;
	FETCH curs1 INTO v_nivid;
	WHILE NOT fincurs1 DO
		CALL  sp_recette_jour_niveau (nojour, v_nivid, v_prix);
		SET v_recette := v_recette +v_prix ;
		FETCH curs1 INTO v_nivid;
	END WHILE;
	CLOSE curs1;
	SET recette := v_recette;
END
