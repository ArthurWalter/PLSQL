CREATE  PROCEDURE  sp_calcul_entree (IN entid INT, OUT prix DECIMAL(4,2))
BEGIN
	DECLARE v_jourin, v_heurein, v_jourout, v_heureout INT;

	SELECT  jour_in, heure_in, jour_out, heure_out 
		INTO v_jourin, v_heurein, v_jourout, v_heureout
	FROM ENTREE	
	WHERE ent_id=entid;
	CALL sp_calcul_prix (v_jourin, v_heurein, v_jourout, v_heureout, prix);
END
